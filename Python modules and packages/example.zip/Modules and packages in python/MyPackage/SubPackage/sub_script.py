def sub_report():
	print("This is a function inside sub script")