def report_main():
	print("This is a function in main script in main package")