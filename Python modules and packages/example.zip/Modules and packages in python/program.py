# To import from main package
from MyPackage import main_script

# To import from subp ackage
from MyPackage.SubPackage import sub_script

# Calling the function in main_script module
main_script.report_main()

# Calling the function in sub_script module
sub_script.sub_report()