def func():
    print("func() in test1.py")

print("top-level in test1.py")

if __name__ == "__main__":
    print("test1.py is being run directly")
else:
    print("test1.py is being imported into another module")
    
    
    
    